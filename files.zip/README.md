# NYC Parking Alert — Skillman / Barnett Ave, Woodside Queens

Sends a weekly email every Saturday summarizing parking issues for your area:
- **Resurfacing work** on or near Skillman Ave, Barnett Ave, and 46th–54th Sts
- **Alternate Side Parking** suspensions for the coming week
- **DOT Traffic Advisories** affecting Skillman or Barnett Ave

---

## Setup (one-time, ~10 minutes)

### 1. Create a Gmail App Password

You need a special app password so GitHub can send email through your Gmail without using your real password.

1. Go to your Google Account → **Security**
2. Make sure **2-Step Verification** is turned on
3. Go to **Security → 2-Step Verification → App passwords** (at the bottom)
4. Create a new app password — name it "Parking Alert"
5. Copy the 16-character password — you'll use it in step 3

### 2. Fork or create this repo on GitHub

Push this folder to a new GitHub repository (can be private).

### 3. Add GitHub Secrets

In your GitHub repo, go to **Settings → Secrets and variables → Actions → New repository secret** and add:

| Secret name | Value |
|---|---|
| `GMAIL_USER` | Your Gmail address (e.g. `you@gmail.com`) |
| `GMAIL_APP_PASSWORD` | The 16-character app password from step 1 |
| `ALERT_EMAIL` | Email address to send the alert to (can be same as above, or different) |

### 4. Enable Actions

Go to the **Actions** tab in your GitHub repo and click **"I understand my workflows, go ahead and enable them"** if prompted.

### 5. Test it manually

Go to **Actions → Weekly Parking Alert → Run workflow** to trigger it immediately and verify you receive the email.

---

## Schedule

The alert runs automatically every **Saturday at 10:00 AM ET** — after NYC DOT typically posts the new weekly advisory.

---

## Updating the ASP calendar

The ASP holiday list in `scripts/parking_alert.py` covers 2026. Each January, update the `ASP_HOLIDAYS` dictionary with the new year's calendar from:
https://www.nyc.gov/html/dot/html/motorist/alternate-side-parking.shtml

---

## Running locally

```bash
pip install -r requirements.txt

# Dry run (prints email to terminal, doesn't send)
python scripts/parking_alert.py --dry-run

# Send for real (requires env vars set)
GMAIL_USER=you@gmail.com GMAIL_APP_PASSWORD=xxxx ALERT_EMAIL=you@gmail.com python scripts/parking_alert.py
```
